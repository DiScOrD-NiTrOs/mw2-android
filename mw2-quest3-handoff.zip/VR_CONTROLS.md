# VR_CONTROLS (PLANNED; nothing implemented in the real game path)
Mapped by xr_input.cpp (scaffold) onto the game's gamepad layout:
LS move | RS look/turn | RT fire | LT ADS | grips = LB/RB equipment | A jump | B crouch |
X reload | Y switch weapon | stick clicks = sprint/melee | left menu = Start.
Planned: dominant-hand controller pose drives aim; snap/smooth turn options.
Status: PLANNED. Requires hooking the real gamepad state and aim vector.
