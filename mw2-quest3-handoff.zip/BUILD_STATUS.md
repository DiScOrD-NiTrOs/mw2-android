# BUILD_STATUS (2026-10-22)
| Item | Status |
|---|---|
| Patch stack 0001-0004 | applies cleanly in order on commit 1c62070c (patch --dry-run) |
| Baseline build (MW2_XR off) | NOT RUN: needs the user's game files + a build environment (Actions or a Linux PC) |
| XR build (MW2_XR on) | NOT RUN, and not before the baseline is green |
| quest-build.yml | written; YAML + embedded shell syntax checked; NEVER RUN |
| Compiled with the project toolchain | NO |
| Tests actually executed | `stereo-test` (g++ here): ok; mutant caught. ctest via tests.yml: not yet run |
| Compile review | one real error found and fixed (SetRunning visibility, 0004); other risks listed in PORT_STATUS |
| APK / Quest install / stereo / head tracking | NONE / NO / NO / NO |
| Committed/pushed by Claude | NO |
