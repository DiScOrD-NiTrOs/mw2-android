# STEREO_DESIGN: how real two-eye rendering can fit this renderer

Evidence base: `renderer_draw.cpp` (861 lines) and `renderer_frame.cpp` (463 lines), uploaded by the user, plus
the earlier source ZIP. NOTHING here is implemented or compiled. Labels: VERIFIED (read in source) / INFERRED / UNKNOWN.

## Verified facts that shape the design
1. **Draws are recorded, not executed inline.** `Draw()` (`renderer_draw.cpp:227`) builds a `DrawOp` whose
   `operator()(VkCommandBuffer) const` replays: push constants, pipeline, viewport, scissor, depth state,
   descriptor sets with dynamic offsets, then `vkCmdDraw[Indexed]` (:135-220). Recording runs on a recorder thread
   (`vk::record::Host(...)`, `renderer_frame.cpp:338`). VERIFIED.
2. **Vertex constants are per-draw data in an arena.** `WriteConstants(...)` returns offsets
   (`constants.vertexFloats`, `.fetch`, `.pixelFloats`, ...) bound as dynamic offsets (:394-398, :772-774). The title's
   view-projection matrix is in that float block, at a shader-dependent register. VERIFIED that it is there;
   UNKNOWN which register (a debug dump of c0-c7 exists under `MW2_TRACE_SHADER_VERTS`, :448).
3. **The world pass is already identifiable.** `FinishFrame` treats a frame as "world drawn" when a depth-less colour
   target took >= 8 multisampled draws (or >= 200 at 1x) (`renderer_frame.cpp:289-301`); the comment says the world
   pass is the only multisampled one. VERIFIED.
4. **The title often does not redraw the world on a present**: "better than half the frames ... are the interface over
   whatever the last world pass left in EDRAM" (`renderer_frame.cpp:285-287`). VERIFIED. Stereo must keep per-eye
   world images across such presents.
5. **A frame ends in one place:** `FinishFrame(VkImage present)` submits, then `vk::ShowImage(present,w,h,frame)`.
   One image out, single view. VERIFIED.
6. **Viewport emulation is normal for 3D draws.** `ViewportOf` (:32-70) maps the Xenos scale/offset into a VkViewport;
   the `ndc[4]` push constant (:604-620) only serves pre-transformed (screen-space, XYZRHW) vertices. So the vertex
   shader of a 3D draw outputs ordinary clip space. VERIFIED from these two files; the translator itself is UNREAD.

## Chosen approach: clip-space eye transform on world-pass draws
Rather than finding and rewriting each draw's matrix, apply a per-eye correction to the vertex shader's output
position. For a draw projected with the game's symmetric projection (tanHalfX, tanHalfY), with clip c = (x, y, z, w). The title is a
Direct3D (left-handed) title: x right, y up, z forward, and **w = view-space depth (positive forward)**. (An earlier draft
of this document used the OpenGL sign, w = -z; that was wrong, corrected here and in the code.)
```
v  = ( x * tanX , y * tanY , w ) - d_eye          // game view space, shifted to the eye's position
e  = conj(Q_eye) rotate v                         // into the eye's axes
c' = ( Pe00*e.x + Pe02*e.z , Pe11*e.y + Pe12*e.z , z , e.z )
```
with Pe00 = 2/(r-l), Pe02 = -(r+l)/(r-l), Pe11 = 2/(u-d), Pe12 = -(u+d)/(u-d) (l, r, u, d = tangents of the eye's half angles).
z is left as the title wrote it: depth ordering within one eye is preserved to first order but is not the exact projected depth (APPROXIMATION, UNVERIFIED visually).
Pure IPD shift reduces to ndc.x change of -d/(tanX*w): disparity falls with depth (checked in tests/stereo_math_test.cpp).
Applies to the world pass only (fact 3); HUD/menus/screen-space draws untouched (they stay mono, to be placed on a
head-locked or world quad later).

### Pieces
- A: per-eye parameters reach the vertex shader (new push-constant block or UBO) - needs `shader_translator.cpp` + `bindings.h`.
- B: the world pass is drawn twice, once per eye, into per-eye colour/depth targets. Doubles world-pass draw CPU and GPU.
  Later optimisation: one pass with `VK_KHR_multiview` (2 layers, `gl_ViewIndex`).
- C: per-eye retention of the last world image for "interface over old world" presents (fact 4); the mono interface pass
  is composited over each eye's world image.
- D: resolve/copy dependencies: the title resolves EDRAM into guest-memory textures (shadows, post effects). Each eye's
  replay must run its own resolve chain in order; shadow maps could be shared (same for both eyes) as an optimisation.
- E: two outputs to the XR layer: `xrc_submit_frame` takes left and right images and submits an
  `XrCompositionLayerProjection` using `xrLocateViews` poses/fovs (replacing the temporary quad).
- F: head/aim separation: head pose delta applies only through R_eye/d_eye; the game's own body/aim angles stay as
  the game computes them; controller aim goes in later through a guest hook (UserCmds) or by pad emulation.

## Open risks (UNKNOWN until tested)
- P00/P11 per draw: the weapon viewmodel may use a different FOV than the world. May require reading the real
  projection constants for each shader. Needs a runtime dump from a PC build.
- Unit scale of view space (IW4 uses inches: ~2.48 units per 63 mm IPD): INFERRED, must be checked.
- Draws that are 3D but not in the multisampled pass (some effects), and 2D draws inside it (rare): classification may need refinement.
- Resolve/EDRAM interactions across two replays (D) are the highest-effort part.
- GPU budget: world pass twice at headset resolution on a mobile GPU. UNMEASURED; expect lowered eye resolution.

## What I need to start writing real code for A-E
`runtime/gpu/vulkan/`: `shader_translator.cpp` (position export, push-constant use), `bindings.h`, `renderer_state.h`,
`renderer_targets.cpp`, `renderer_resolve.cpp`, `recorder.h` + `recorder.cpp`. Optional but valuable: a PC-build log
with `MW2_TRACE_SHADER_VERTS=<hash>` from a world draw (shows c0-c7 and the shader).

## Update after reading shader_translator.cpp, renderer_state.h, renderer_targets.cpp, renderer_resolve.cpp, recorder.*
VERIFIED: the vertex epilogue already post-processes `m_position` (shader_translator.cpp ~2319), push constants are a
fixed layout (bindings.h; 128 B guaranteed, 112 B used with the eye block), targets are keyed by `TargetKey` in
`g.targets` (FindTarget/EnsureTarget are the only lookups), resolve destinations by guest address in `g.resolvedTo`
(renderer_draw.cpp:91, renderer_resolve.cpp:36 and :362), and per-command-buffer bound state resets in
renderer_frame.cpp:80. Occlusion queries and read-backs can stay left-eye only.

Mirroring plan (stage 2b, NOT implemented): add `eye` to `TargetKey` (set inside FindTarget/EnsureTarget from
`stereo::Eye()`), namespace `resolvedTo` keys with bit 31 for the right eye (physical addresses fit below it; to be
confirmed), wrap `Draw`, `Resolve` and `Swap` so each runs once per eye, give `FinishFrame` a right-eye present image
and a `ShowImageStereo`. Because the right eye then has its own EDRAM namespace, "interface over the last world pass"
frames keep a correct right-eye world image. Cost: the whole frame is rendered twice (UNMEASURED).
