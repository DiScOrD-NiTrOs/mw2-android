# PORT_STATUS: MW2 (2009) native Quest 3 VR port

Source of truth: uploaded ZIP = mw2-android commit `1c62070cca647a439731b3ca4a23d454c690e2ef` (518 files).
Labels: VERIFIED FROM SOURCE | VERIFIED BY TEST | INFERRED | BLOCKED | NOT STARTED.
Line numbers refer to that pristine tree.

## Environment (VERIFIED BY TEST, this session)
Java 21 runtime only (no jni.h), g++ present, no CMake, no Android SDK/NDK, no Vulkan or OpenXR
headers, no network, no GitHub access. => **No build, no APK, no headset test is possible here.**
Checks actually run: `patch --dry-run` of the patch on the pristine tree (clean), and
`g++ -fsyntax-only` of `runtime/xr/xr_pad_bridge.cpp` against the REAL `runtime/android/android.h`
with stub jni.h/vulkan.h (passed). That is a syntax check, not a build.

## Architecture (VERIFIED FROM SOURCE)
- Game logic = Xbox 360 PowerPC code statically recompiled into `ppc/` (114 files, generated from the
  user's own game files). Not readable engine source. The runtime hooks guest functions with
  `GUEST_HOOK(T_name)` at fixed addresses per title/version (`runtime/title.h`).
- Renderer = Xbox 360 GPU emulation: `runtime/gpu/command_processor.cpp`, `shader_translator.cpp`,
  `vulkan/renderer_*.cpp`. The camera is NOT a C++ object; it reaches the GPU as shader constants.
- **Frame hand-off (the stereo boundary):** `runtime/gpu/vulkan/presenter.h` `vk::ShowImage(image,w,h,serial)`
  receives a FINISHED 2D VkImage (TRANSFER_SRC). The presenter runs on its own thread
  (`presenter.cpp` Worker :1187, DrawOneFrame :820). Everything upstream of that image is single-view.
- Vulkan is called through run-time-loaded entry points (`runtime/gpu/vulkan/loader.h`, `MW2_VULKAN_DYNAMIC`);
  Vulkan sources are compiled with `-include loader.h` (`cmake/android.cmake`). Instance: `presenter.cpp`
  CreateInstance :224 (vkCreateInstance :294); physical device PickDevice :312; CreateDevice :359 ->
  `pipeline.cpp` CreateDevice (vkCreateDevice :385); a second instance for headless use at `pipeline.cpp:461`.
  Window path: CreateSurfaceForWindow :1045, CreateSwapchain :404, present `vkQueuePresentKHR` :975.
- Custom GPU driver loader (libadrenotools) in `runtime/android/driver.cpp`: must be bypassed for OpenXR.
- Input: `android::input::SetHardwarePad(user, Pad)` / `SetHardwarePadConnected` (`runtime/android/android.h`
  :101-145); consumed by `runtime/kernel/input.cpp:372`; existing JNI entry `nativePadState`
  (`runtime/android/jni.cpp:452`). Pad = XInput bit layout. **This is the correct Touch-input integration point.**
- Camera-related hooks that EXIST: `T_CG_ViewFov`, `T_CG_CullZoom` (`runtime/field_of_view.cpp`, scales FOV),
  `T_D3D_Present` (frame boundary), campaign `T_CoopFrame_UserCmds`. Client state (campaign): origin at
  ClientStates+133188, angles at +149388, read in `runtime/player.cpp:735-739`.
- **VERIFIED ABSENT from `title.h`:** any named scene-render / refdef / view-matrix / usercmd-view-angle
  function. True stereo and head tracking need guest addresses that this repo does not contain.
- Android: `AndroidManifest.xml` has MainActivity (launcher) and GameActivity (process `:game`), no VR
  categories or headtracking feature; Gradle: minSdk 26, targetSdk 35, NDK 28.2.13676358, arm64-v8a only,
  flavors `campaign` (`com.mw2.recomp.sp`) / `multiplayer`; native build = root `CMakeLists.txt` via
  `cmake/android.cmake`. GameActivity.kt/surface handling not read (INFERRED: SurfaceView + ANativeWindow).

## Changed this session (`0001-xr-stage1a.patch` then `0002-xr-stage1b.patch`, `git apply` in order)
All behind `MW2_XR` (CMake option, default OFF) and `xrc_initialized()`, so the phone build is unchanged.
| File | Change | Status |
|---|---|---|
| `CMakeLists.txt`, `cmake/android.cmake` | `MW2_XR` option; globs `runtime/xr/*.cpp`, links `third_party/openxr` loader | unbuilt |
| `runtime/xr/xr_runtime.{h,cpp}` | OpenXR instance, enable2 wrappers, session, swapchain, frame loop (flat quad layer, TEMPORARY) | unbuilt |
| `runtime/xr/xr_input.{h,cpp}` | Touch actions -> gamepad state | unbuilt |
| `runtime/xr/xr_pad_bridge.{h,cpp}` | gamepad state -> `android::input::SetHardwarePad(0,...)` | syntax OK vs real android.h |
| `runtime/gpu/vulkan/presenter.cpp` | XR branch: instance via runtime, device via runtime, no swapchain ext | unbuilt |
| `runtime/gpu/vulkan/pipeline.cpp` | device created through the runtime when XR is up | unbuilt |

## Feature table
| Feature | Status |
|---|---|
| OpenXR instance/device creation in the real Vulkan setup | PARTIAL (hooks written, unbuilt) |
| XR session + frame loop wired into presenter | PARTIAL (stage 1b written: Bring/Worker/DrawOneXrFrame, `nativeXrInit`, Kotlin call, manifest; unbuilt, flat quad only) |
| Touch -> game gamepad path | PARTIAL (bridge called from DrawOneXrFrame; unbuilt, unrun) |
| Stereo rendering | BLOCKED (see below) |
| 6DoF head tracking in game camera | BLOCKED (same boundary) |
| Motion-controller aiming | NOT STARTED |
| HUD/menus in VR, audio, perf, APK | NOT STARTED; no APK exists |

## Exact blockers
1. **Stereo/head tracking:** need guest addresses for the scene render entry and the camera/refdef (or the
   usercmd view angles) for the user's game version, plus how the view-projection reaches the VS constants.
   They come from analysing the user's own XEX (the KisakCOD decompilation is the naming map), or from a
   runtime dump of per-draw VS constants. `runtime/gpu/vulkan/renderer_diagnostics.cpp` (846 lines) may
   already dump constants: not yet read.
2. No toolchain/network here; nothing has compiled.
3. Baseline recompile needs the user's own XEX/ISO.

## Candidate stereo designs (INFERRED, to be validated)
A. Hook the guest scene-render entry; run it twice per displayed frame with +/- IPD/2 view offset and
   per-eye projection; game logic runs once; renderer outputs two images. Costs 2x GPU + render CPU.
B. Host-side: replay one command stream with per-eye view-projection VS constants (needs reliable
   constant identification). Higher risk.

## Next exact actions
1. User applies the patch, runs a build (local or Actions) with `-DMW2_XR=OFF` first to prove the baseline,
   then ON after adding `third_party/openxr`. Send the log.
2. Stage 1b: `xrc_init` call site (JavaVM + Activity), presenter Worker/Bring/swapchain XR branch,
   `xr::PumpPad()` per frame, manifest VR entries.
3. Stage 2: find guest scene-render/camera addresses (blocker 1).

## Stage 1b (0002-xr-stage1b.patch) (written, NOT built)
| File | Change |
|---|---|
| `runtime/android/jni.cpp` | new `nativeXrInit(activity)`: global-refs the Activity, `xrc_init(g_vm, ref, nullptr)`; returns false without MW2_XR |
| `android/.../NativeBridge.kt`, `GameActivity.kt` | declares and calls `nativeXrInit(this)` right before `nativeStart` (VERIFIED: GameActivity.kt:408 region; the game runs in process `:game`) |
| `runtime/gpu/vulkan/presenter.cpp` | `Bring()` XR branch (no window/surface/swapchain; instance, device, `xrc_begin`); `DrawOneXrFrame()` consumes the SAME frame queue protocol as `DrawOneFrame` (pop oldest, copy, advance `g.taken`, `stutters::Shown`); `Worker` loop dispatches to it; `FollowTheDisplay` skipped in XR |
| `runtime/xr/xr_runtime.*` | `xrc_set_queue_lock` so the XR copy holds `vk::pipeline::QueueMutex()`; queue index 0 matches `pipeline.cpp:404` (VERIFIED) |
| `AndroidManifest.xml` | headtracking uses-feature (required=false), `com.oculus.supportedDevices`, VR/IMMERSIVE_HMD intent filter on GameActivity; XML parses; Quest behaviour UNVERIFIED |
Checks run: both patches apply cleanly in order to the pristine tree (`patch --dry-run`); presenter.cpp braces and #if/#endif balance (203/203, 26/26); manifest is well-formed XML. NOT run: any compile.

Known gaps in stage 1b: `Teardown()` has no XR path (ending a run is process exit per jni.cpp comment, so low risk);
frame pacing between guest 60 Hz and headset 72+ Hz unmeasured; presenter still submits a flat quad.

## New verified finding for stereo (design B)
Vertex constants are 256 float4 registers (`bindings.h` `kFloatConstants`), bound as dynamic uniform buffers
(`pipeline.cpp:522-528`, `shader_translator.cpp:457`); `renderer_diagnostics.cpp:719` already hashes the
`gpu::SQ_VS_CONST` window per draw. So per-draw constants are observable at a known place; the open problem is
identifying which register block holds the view-projection matrix (shader-dependent). Next: read
`renderer_draw.cpp` where the constant window is uploaded/bound.

## Stereo design update (STEREO_DESIGN.md; design only, nothing implemented)
New verified facts from renderer_draw.cpp / renderer_frame.cpp: draws are recorded as replayable `DrawOp`s; per-draw vertex
constants live in an arena bound by dynamic offset; the world pass is already detected (multisampled depth-less target
draws); the title often presents interface-only frames over the previous world image; frames leave only through
`FinishFrame` -> `vk::ShowImage`. Chosen approach: clip-space per-eye transform on world-pass draws + two world passes
+ per-eye retention + projection layer. Stereo status: DESIGNED, NOT IMPLEMENTED, BLOCKED ON shader_translator.cpp,
bindings.h, renderer_state.h, renderer_targets.cpp, renderer_resolve.cpp, recorder.*.

## Stage 2a (0003-xr-stage2a.patch): eye-transform plumbing, DORMANT until stage 2b
| Item | Evidence |
|---|---|
| `runtime/gpu/vulkan/stereo.{h,cpp}`: EyeView, MakeEyeView, TransformClip, state | **VERIFIED BY TEST** (CPU math) |
| `tests/stereo_math_test.cpp` (registered in tests/CMakeLists.txt as `stereo`) | built with g++ and run here: `stereo-test: ok`; a sign-flip mutant is caught (it fails) |
| Vertex shader epilogue + 5-member push block (`shader_translator.cpp`, `MW2_XR` only) | written; NOT compiled, SPIR-V NOT validated; member offsets are non-monotonic (32 after 96): should be legal, UNVERIFIED |
| `pipeline.cpp` vertex push range grows to 112 B; `renderer_draw.cpp` pushes the block (on for the multisampled, viewport-transformed pass; off otherwise); shader cache salt in `renderer_pipelines.cpp` | written; NOT compiled |
Paren/brace and #if balance checked on all touched files (renderer_draw.cpp's one extra `)` is in the pristine file).
The patch stack 0001+0002+0003 applies cleanly to commit 1c62070c (`patch --dry-run`).
Nothing turns the transform on yet: `stereo::Active()` is never set, so every draw pushes the disabled block.
Still UNKNOWN: the game's own tanHalfX/Y at run time (needs the T_CG_ViewFov hook or a constants dump), whether the
weapon viewmodel uses a different FOV, and the real unit scale (IW4 inches INFERRED).

## Build-readiness review (this session)
Verified against the real tree by grep/reading: every identifier my presenter, JNI, translator and draw edits use
exists with a compatible signature (SetStatus, Initialise, DeviceName, QueueMutex, frame_rate::Console, stutters::Shown,
Presenter::Queued, g_vm, MW2_NATIVE, ConstantF/ConstantU/Pointer/m_bool, Op::Select/FOrdNotEqual, <cstring> in draw);
all 15 Vulkan calls used by xr_runtime.cpp are in `vulkan_functions.inc`; `MW2_VULKAN_DYNAMIC` is target-wide so the
xr sources see it (they include loader.h explicitly, as the `-include` property only covers the Vulkan files);
the repo has no -Werror. **One real compile error found and fixed (0004):** `android::detail::SetRunning` is declared
only inside jni.cpp, so presenter.cpp could not see it; 0004 declares it under MW2_XR. 0004 also adds the Gradle switch
`MW2_XR=1` -> `-DMW2_XR=ON`.
Remaining LIKELY first-build risks (UNVERIFIED): Khronos headers vs my use of the typedef aliases; the translator's
non-monotonic push-member offsets (spirv-val); anything the real compiler finds that stubs cannot.
Baseline CI: `quest-build.yml` is written and its YAML and every shell block parse; it has not run.
