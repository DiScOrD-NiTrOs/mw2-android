# BUILD_INSTRUCTIONS: a practical route to an Android APK

**Status: NOTHING HERE HAS BEEN RUN.** The sandbox these were prepared in has no NDK, no CMake, no network and no
GitHub access, so no build has been attempted. Every command below was checked against the repository's own files
(commit `1c62070c`) and is labelled VERIFIED FROM REPO FILES, not "works".

## What the repository says (VERIFIED FROM REPO FILES)
- Android build: JDK 17, NDK `28.2.13676358`, `platforms;android-35`, `build-tools;35.0.0`, `cmake;3.22.1`,
  Gradle 8.11.1 (`android.yml`, `build.gradle.kts`); the repo has `android/gradlew` and the README uses
  `./gradlew assembleCampaignTu0Release`.
- Gradle variants = flavour `campaign|multiplayer` x `tu0|tu6`. **TU0 = the disc's own executables, no title update
  needed.** Use `assembleCampaignTu0Debug` (debug key, installable) or `...Release`.
- The recompiled C++ is generated from YOUR game, never shipped: `VERSION=tu0 RECOMPILE_ONLY=1 TITLE=sp ./build.sh`
  writes `ppc_tu0/`; CMake picks `ppc_tu0` for tu0 (`CMakeLists.txt` lines ~48-52). It needs
  `mw2/tu0/default.xex` and `mw2/tu0/default_mp.xex` (or `ISO=<disc image>`), clang-18/lld-18/ninja/cmake/python3.
- `android/fetch_deps.sh` fetches libadrenotools. `tests.yml` (runs on every push, no game files) builds `tests/`
  and runs ctest; it now includes the `stereo` check.
- Note: the repo's `android.yml` runs `build.sh` with the default `VERSION=tu6` but builds `...Tu0...` variants. For
  the TU0 baseline the commands above (`VERSION=tu0`) are what `build.sh` and CMake actually pair up. UNRESOLVED:
  whether that mismatch in `android.yml` is a stale workflow or works by a path I have not read.

## Route A (recommended): GitHub Actions, `quest-build.yml`
Needs from you (I cannot do these): (1) your repo containing mw2-android + the patches, (2) Actions enabled on it
(forks start disabled: Actions tab -> enable), (3) links to YOUR OWN `default.xex` and `default_mp.xex` (or an ISO):
a private Hugging Face repo + `HF_TOKEN` secret, or a Drive "anyone with the link" file, as workflow inputs or
secrets `GAME_ARCHIVE_URL` / `DEFAULT_XEX_URL` / `DEFAULT_MP_XEX_URL` / `ISO_URL`. Nothing of the game is kept
(`rm -rf mw2` before the Gradle step) and none ends up in an artifact.

1. In a clone of your repo (base = upstream commit `1c62070c`):
   `git apply 0001-xr-stage1a.patch 0002-xr-stage1b.patch 0003-xr-stage2a.patch 0004-xr-review-fixes.patch`
   then copy `.github/workflows/quest-build.yml` in, commit, push.
2. Actions -> **quest-build** -> Run workflow: `xr = off`, `build_type = debug`, plus your game links.
   This is the BASELINE: the patches are in the tree but `MW2_XR` is OFF, so the phone build is unchanged.
3. First runs are long (about two million generated C++ lines compiled for arm64). If it hits the 6 h limit, run it
   again: the compiler cache is saved even on failure and the recompiled tree is cached.
4. Download artifacts `quest-build-logs-xr-off` (always saved: `build-report.txt`, `gradle.log`, `recompile.log`,
   CMake logs) and `quest-apk-xr-off`. `build-report.txt` lists the APK's signature check, manifest badging and its
   `lib/` entries, so you can see whether `lib/arm64-v8a/libmw2.so` is there.
5. Only when step 2 is green: run again with `xr = on`. It downloads the Khronos OpenXR loader AAR from Maven
   Central (the workflow prints the version it resolved) into `third_party/openxr/` and builds with `MW2_XR=1`
   (Gradle env -> `-DMW2_XR=ON`). Send me `quest-build-logs-xr-on`; I fix the compile errors first.
   UNVERIFIED: that the Khronos loader (rather than Meta's mobile-SDK loader) works on Quest; if the session fails
   at `xrCreateInstance`, the Meta loader is the fallback.

## Route B: a Linux PC (no CI)
```
sudo apt-get install -y clang-18 lld-18 ninja-build ccache cmake python3 p7zip-full   # + JDK 17, Android SDK/NDK above
mkdir -p mw2/tu0 && cp <your>/default.xex <your>/default_mp.xex mw2/tu0/
VERSION=tu0 RECOMPILE_ONLY=1 TITLE=sp ./build.sh
./android/fetch_deps.sh
cd android && ./gradlew assembleCampaignTu0Debug
# XR: place OpenXR headers at third_party/openxr/include/openxr/ and the arm64 libopenxr_loader.so at
# third_party/openxr/lib/arm64-v8a/, then:  MW2_XR=1 ./gradlew assembleCampaignTu0Debug
```
APK: `android/app/build/outputs/apk/campaign/debug/app-campaign-debug.apk` (the exact name pattern is in `android.yml`).

## Installing on a Quest 3
Developer Mode, USB, `adb install -r <apk>`. The app needs your own game data at first start (see the upstream
README). Whether the app runs at all on Horizon OS, and whether the VR manifest entries are honoured, is UNVERIFIED.

## Tests that need no game files
`stereo-test` (the per-eye maths) was built with plain g++ and run in the sandbox: it passed, and a sign-flip mutant
made it fail. Through the project's own harness: `cmake -S tests -B build-tests -G Ninja && cmake --build build-tests &&
ctest --test-dir build-tests --no-tests=error --output-on-failure` (this is exactly what `tests.yml` does on each push).
